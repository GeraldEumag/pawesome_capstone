<?php

use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use League\Flysystem\FilesystemException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Trust X-Forwarded-* from the deployment edge (Railway/Render/Vercel all
        // terminate TLS upstream). Without this, url()/asset()/mail links come
        // out as http:// and SESSION_SECURE_COOKIE breaks behind the proxy.
        $middleware->trustProxies(at: env('TRUSTED_PROXIES', '*'));
        $middleware->use([
            \App\Http\Middleware\Cors::class,
            \App\Http\Middleware\SecurityHeaders::class,
        ]);
        $middleware->appendToGroup('api', \App\Http\Middleware\NormalizeApiResponse::class);
        $middleware->alias([
            'role' => \App\Http\Middleware\EnsureRole::class,
            'auth.api' => \App\Http\Middleware\ApiTokenAuth::class,
            'kiosk.pin' => \App\Http\Middleware\KioskPinAuth::class,
            'throttle' => \Illuminate\Routing\Middleware\ThrottleRequests::class,
            'verified' => \App\Http\Middleware\EnsureEmailIsVerified::class,
        ]);
        $middleware->redirectGuestsTo(function (Request $request) {
            return $request->is('api/*') ? null : '/login';
        });
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->render(function (AuthenticationException $exception, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'message' => 'Unauthenticated.',
                ], 401);
            }
        });
        $exceptions->render(function (FilesystemException $exception, Request $request) {
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'message' => 'File storage is temporarily unavailable. Your upload was not saved; please try again.',
                ], 503);
            }
        });
    })->create();
